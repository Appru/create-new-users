﻿describe('create a ninja account',function (){


//replace the 'i=0' with what ever fan account your on
//replace 'jem' with fan or whatever you want
    //can change the password too

  //make sure to change value of usernames and passwords to that of your own



it('creates ninja account', function () {

//////////////////CHANGE THESE VARIABLES EVERY TIME////////////////
var i;

for (i= 0; i<1;i++){ 

///////////////////////////////////////////////////////////
cy.visit('https://supapass.com/login')


/**
 * Hi Jem! I'm probably still at lunch, but managed to get it working.
 * run `cypress run --headed` in this directory: /Users/jem 1/Documents/ninja_cypress
 * and it will pick up your account ID and password that you set as
 * ENV variables in your `~/.bash_profile`.
 * 
 */


cy.get('input[type=text]')
        .type(Cypress.env('ACCOUNT_ID'))

cy.get('input[type=password]')
        .type(Cypress.env('SUPAPASS_PASSWORD'))

cy.contains('Login with Email').click()




cy.visit('https://supapass.com/admin/people/create')


cy.get('#edit-name')
    .type('fan'+i)


cy.get('#edit-mail')
    .type('fan+'+i+'@supapass.com')


cy.get('#edit-pass-pass1')
    .type('password123')

cy.get('#edit-pass-pass2')
    .type('password123')


cy.get('#edit-roles-145878930')
    .click()


cy.get('#edit-submit')
    .click()





  }      

})

it('adds new ninja account to 1password', function (){

var i;
for (i= 0; i<1;i++){

cy.visit('https://my.1password.com/vaults/peb53ffvl4fbeqypatnoh6mg7u/allitems/zbxudrnddjdf7it7r57kecql7y')


cy.get('#email')
    .type(Cypress.env('1PASSWORD_NAME'))


cy.get('#account-key')
    .type(Cypress.env('1PASSWORD_KEY'))
//need to make this more secure lol

cy.get('#master-password')
    .type(Cypress.env('1PASSWORD_MASTER'))
cy.get('.new-button')
    .click()

cy.wait(10000)


cy.get('.add')
    .click()

cy.get('.toolbar > ul > :nth-child(1)')
    .click()

//title
cy.get('h1 > input')
    .type('fan '+i)

//username
cy.get('.section-username-password > tbody > .field.string > .value > .value-input')
    .type('fan+'+i+'@supapass.com')

//password
cy.get('.field.concealed > .value > .value-input')
    .type('password123')



cy.get('.save')
    .click()


}

   })


})